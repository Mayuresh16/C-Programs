#include <stdio.h>
#include <string.h>
#include <strings.h>
#include <stdlib.h>
#include <stdbool.h>
#include "SingleCircularList.h"

NODE* createList(NODE* start) {
    NODE *newNode;
    //allocating memory for new node
    newNode = (NODE*) malloc(sizeof ( NODE));
    //checking if memory allocation is unsuccessful
    if (newNode == NULL) {
        printf("\nInsufficient memory\n");
    } else {
        //if allocation is successful accept data in the record
        acceptData(newNode);

        /* if list is empty; make new node the first node */
        if (isListEmpty(start)) {
            newNode->next = newNode;
            /* Since it's the only node in the list; 
             * new_node's next points to itself */
        } else {
            /* make new node's next point to first node.
             * start is pointing to last node therefore start->next gives 
             * address of first node */
            newNode->next = start->next;
            /* make existing last nodes next (start->next) point to the 
             * new node */
            start->next = newNode;
        }
        /* make start point to the latest node added to the list */
        start = newNode;
    }
    return start;
}

void displayList(NODE *start) {
    NODE *ptr; //used for traversing the list

    //check if the list is empty
    if (isListEmpty(start)) {
        printf("\nThe list is empty\n");
    } else {
        /* last node's next (start->next) stores address of first node; 
         * make start pointer point to the actual first node in the list*/
        start = start->next;
        /* make ptr point to the first node*/
        ptr = start;
        do {
            printf("\n\tRoll No = %d\tName : %s", ptr->roll, ptr->name);
            ptr = ptr->next; //goto next node
        } while (ptr != start);
        /* traversing the list till ptr does not come back to the first node*/
    }
    return;
}

/* deletion of node from the list by searching 
 * the node by the student name */

NODE* deleteNode(NODE * start, const char * nameToDelete) {
    /* to traverse to the node that is to be deleted */
    NODE *ptr;
    /* to point to previous node of the node to be deleted */
    NODE *temp;
    /* indicator which will be set to false if the name is not found */
    bool hasFound = true;

    /* check whether the list is empty */
    if (isListEmpty(start)) {
        printf("\tThe list is empty !!!\n");
    } else {
        /* search for the Student by name.
         * To start searching from the last node make ptr point to start */
        ptr = start;
        while (strcasecmp(nameToDelete, ptr->name) != 0) {
            temp = ptr;
            ptr = ptr->next;
            /* if name is not found i.e. ptr has traversed the 
             * entire list to come back to the last node  */
            if (ptr == start) {
                hasFound = false;
                break; //terminate the while loop
            }
        } //end of while loop

        if (hasFound == false) {
            /* if the name is not found */
            printf("\tStudent: %s is not present in the list\n", nameToDelete);
        } else {
            /* if first node has to be deleted */
            if (ptr == start) {
                /* list contains only one node ie start->next 
                 * is pointing to itself  */
                if (start == start->next) {
                    start = NULL;
                } else {
                    /* traverse temp to the penultimate in the list */
                    temp = start;
                    while (temp->next != start) {//temp->next != ptr
                        temp = temp->next;
                    }
                    // when more than one nodes are present in the list
                    temp->next = ptr->next;
                    // make the penultimate node; the new last nodes
                    start = temp;
                }
            } else {
                /* node other than start has to be deleted  */
                temp->next = ptr->next;
            }
            printf("\t\t%s has been deleted!\n", nameToDelete);
            free(ptr); //delete node
        }
    }
    return start;
}

void insertNode(NODE *start) {
    /* For creation of new node*/
    NODE *newNode;
    /* for traversing the to node after which the new node is to inserted */
    NODE *ptr;
    /* To accept the name to be searched*/
    char nameToSearch[ MAX_NAME_LENGTH ];
    /* indicator that will be set to false if the name is not found */
    bool hasFound = true;
    /*is list empty */
    if (isListEmpty(start)) {
        printf("\tList is not existing\n");
        return;
    }

    printf("\tEnter the name of the Student\n\t" \
    "after which new node is to be inserted : ");
//    scanf("%s", tname);
    fgets(nameToSearch,MAX_NAME_LENGTH,stdin);
    /* searching for the Student name from the end of the list*/
    ptr = start;
    while (strcasecmp(nameToSearch, ptr->name) != 0) {
        ptr = ptr->next;
        if (ptr == start) {
            /* the name is not found after  cycling through entire list */
            hasFound = false;
            break;
        }
    } //end of while loop
    if (hasFound == false) {
        printf("\tThe name %s is not present in the list\n", nameToSearch);
    } else {
        /* allocating memory for new node */
        newNode = (NODE*) malloc(sizeof ( NODE));

        /* checking whether the heap is full ie if allocation has failed */
        if (newNode == NULL) {
            printf("\nInsufficient memory! New Node could not be created\n");
        } else {
            /* accepting details if the memory is successfully allocated*/
            acceptData(newNode);
            /*inserting the new node in the list*/
            newNode->next = ptr->next;
            ptr->next = newNode;
        }
    }
    return;
}

/* Returns true if the list is empty*/
bool isListEmpty(NODE * start) {
    return (start == NULL);
}

/*Accept data in the node */
void acceptData(NODE *newNode) {
    printf("\tPlease enter the roll number : ");
    scanf("%d", &newNode->roll);
    printf("\tPlease enter the name  : ");
    while (getchar() != 10); //clear stdin
    fgets(newNode->name, MAX_NAME_LENGTH, stdin);
    //    scanf("%s", newNode->name);
    return;
}