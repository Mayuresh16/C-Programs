/* 
 * File:   main.c
 * Author: Mayuresh Kedari
 *
 * Created on 6 October, 2018, 8:33 PM
 */

/* Single Circular Linked list using local variables
        creation
        deletion
        insertion
        display
 */
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include "SingleCircularList.h"

#define CREATE_LIST 1
#define INSERT_NODE 2
#define DELETE_NODE 3
#define DISPLAY_LIST 4
#define EXIT_CHOICE 5
/*displays operations menu*/
int displayMenuChoice(void);

int main() {
    char name[MAX_NAME_LENGTH];
    //initialize the list to be empty
    NODE* start = NULL;
    int choice;
    do {
        choice = displayMenuChoice();
        switch (choice) {
            case CREATE_LIST:
                start = createList(start);
                break;
            case INSERT_NODE:
                insertNode(start);
                break;
            case DELETE_NODE:
                printf("\tEnter name of the Student to be deleted: ");
//                while (getchar() != 10); //clear stdin
                fgets(name, MAX_NAME_LENGTH, stdin);
                start = deleteNode(start, name);
                break;
            case DISPLAY_LIST:
                displayList(start);
                break;
            case EXIT_CHOICE:
                printf("\nFInished with list operations !!\n ");
                break;
            default:
                printf("\nIncorrect choice !!!\n ");
        }
    } while (choice != EXIT_CHOICE);
    return EXIT_SUCCESS;
}

int displayMenuChoice(void) {
    int choice;
    printf("\n\t**** SINGLE CIRCULAR LINKED LIST  ****");
    printf("\n\t1]\tCreate or Append List ");
    printf("\n\t2]\tInsert node in the List ");
    printf("\n\t3]\tDelete node from the List ( By Name )");
    printf("\n\t4]\tDisplay  List ");
    printf("\n\t5]\tExit");
    printf("\n\n\tPlease enter your choice (1/2/3/4/5 ): ");
    scanf("%i", &choice);
    while(getchar()!='\n');
    return choice;
}

