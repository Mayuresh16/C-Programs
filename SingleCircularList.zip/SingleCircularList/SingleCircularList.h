
/* 
 * File:   SingleCircularList.h
 * Author: Mayuresh Kedari
 *
 * Created on 6 October, 2018, 6:49 PM
 */

#ifndef SINGLECIRCULARLIST_H
#define SINGLECIRCULARLIST_H

#ifdef __cplusplus
extern "C" {
#endif
#define MAX_NAME_LENGTH 10

struct STUDENT {
    int roll;
    char name[ MAX_NAME_LENGTH ];
    struct STUDENT *next;
};
typedef struct STUDENT NODE;

/*Insert a new node in the list at the end*/
NODE* createList(NODE*);
/*Display all Nodes from the list*/
void displayList(NODE*);
/*Delete node from the list*/
NODE* deleteNode(NODE*,const char * nameToDelete);
/*Insert new node in the list*/
void insertNode(NODE*);
/*Accept data in the node */
void acceptData(NODE *);
/* Returns true if the list is empty otherwise returns false*/
bool isListEmpty(NODE *);

#ifdef __cplusplus
}
#endif

#endif /* SINGLECIRCULARLIST_H */

