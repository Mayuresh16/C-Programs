/* 
 * File:   StackImpl.cpp
 * Author: Mayuresh
 *
 * Created on 14 October, 2018, 3:59 PM
 */

#include <cstdlib>
#include "MyStack.h"
using namespace std;

const char* StackUnderFlow :: what() const throw()
{
    return "\tThe Stack is EMPTY!\n";
}
const char* StackOverFlow :: what() const throw()
{
    return "\tThe Stack is FULL!\n";
}

/*creates stack object */
Stack :: Stack()
{
    top = -1;
}
/*destroys stack object  */
Stack :: ~Stack()
{
    top = -1;
    for(int idx = 0; idx < MAXSIZE;idx++){
        container[idx] = 0; 
    }
}
/*adds an ITEMTYPE element to a stack;
 on failure throws StackOverflow() exceptions*/
void Stack :: push(ITEMTYPE data)
{
    if(isStackFull())
    {
        throw StackOverFlow();
    }
    else
    {
        container[++top] = data;
//        cout << "\tElement " << data << " inserted successfully!" << endl;
    }
    return;
}
/*deletes and returns topmost element from stack;
 * on failure throws StackUnderflow() exception
 */
ITEMTYPE Stack :: pop(void)
{
    ITEMTYPE data;
    if(isStackEmpty())
    {
        throw StackUnderFlow();
    }
    else
    {
        data =  container[top--];
    }
    return data;
}
/*returns top most element from stack*/
ITEMTYPE Stack :: peek(void) const
{
    if(isStackEmpty())
    {
        throw StackUnderFlow();
    }
    else
    {
        return container[top];
    }

}
/*check whether the stack is full  */
bool Stack :: isStackFull(void) const
{
    return (top == MAXSIZE - 1);
}
/*check whether the stack is empty */
bool Stack :: isStackEmpty(void) const
{
    return (top == -1);
}
/*Displays the content of the stack*/
void Stack :: display(void) const
{
    if(isStackEmpty())
    {
        throw StackUnderFlow();
    }
    else
    {
        int index = top;
        cout << "\tContents of the Stack: " << endl;
        while(index != -1)
        {
            cout << "\tElement : " << container[index--];
        }
        cout << endl;
    }
    return;
}