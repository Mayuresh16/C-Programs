/* 
 * File:   stack.cpp
 * Author: Mayuresh Kedari
 *
 * Created on 14 October, 2018, 3:47 PM
 */

#include <cstdlib>
#include <iostream>
#include "MyStack.h"
using namespace std;

#define PUSH 1
#define POP 2
#define PEEK 3
#define DISPLAY 4
#define EXIT_OPTION 5
int getMenuChoice(void);

int main(void) 
{
    int choice;
    Stack stk;
    ITEMTYPE data;
    
    do
    {
        choice = getMenuChoice();
        try{
            switch(choice)
            {
                case PUSH:
                    cout << "\tEnter integer element: ";
                    cin >> data;
                    stk.push(data);
                    break;
                case POP:
                    data = stk.pop();
                    cout << "\tElement : " << data << " deleted successfully!" << endl;
                    break;
                case PEEK:
                    data = stk.peek();
                    cout << "\tTop-Most Element : " << data << endl;
                    break;
                case DISPLAY:
                    stk.display();
                    break;
                case EXIT_OPTION:
                    cout << "\nFinished with Operations!" << endl;
                    break;
                default:
                    cout << "Invalid choice!" << endl;
            }
        }
        catch(StackUnderFlow& suf)
        {
            cerr << suf.what() << endl;
        }
        catch(StackOverFlow& sof)
        {
            cerr << sof.what() << endl;
        }
        catch(...){
          cerr << "Something went wrong!" << endl;  
        }
    }while(choice != EXIT_OPTION);

    return EXIT_SUCCESS;
}

int getMenuChoice() {
    int choice;
    cout << "\n\n\t**** Operation on Stack of Integers ****\n";
    cout << "\t1] Add element "<< endl ;
    cout << "\t2] Delete element "<< endl ;
    cout << "\t3] Retrieve Top-Most element "<< endl ;
    cout << "\t4] Display contents" << endl;
    cout << "\t5] Quit "<< endl ;

    cout << "\tPlease enter your choice (1/2/3/4/5) : ";
    cin >> choice;
    cout << endl;
    return choice;
}

