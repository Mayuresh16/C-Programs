/* 
 * File:   MyStack.h
 * Author: Mayuresh Kedari
 *
 * Created on 14 October, 2018, 3:47 PM
 */

#ifndef MYSTACK_H
#define	MYSTACK_H

#include<iostream>
#include<stdexcept>
#define MAXSIZE 5
using namespace std;
typedef int ITEMTYPE;
class StackUnderFlow : public exception
{
public:
   const char* what() const throw() override;  
};

class StackOverFlow : public exception
{
public:
   const char* what() const throw() override;  
};

class Stack {
private:
    ITEMTYPE container[MAXSIZE];//stack of ITEMTYPE
    int top;
public:
    /*creates stack object */
    Stack();
    /*destroys stack object  */
    ~Stack();
    /*adds an ITEMTYPE element to a stack;
     on failure throws StackOverflow() exceptions*/
    void push(ITEMTYPE)  ;
    /*deletes and returns topmost element from stack;
     * on failure throws StackUnderflow() exception
     */
    ITEMTYPE pop(void) ;
    /*returns top most element from stack*/
    ITEMTYPE peek(void) const ;
    /*check whether the stack is full  */
    bool isStackFull(void) const;
    /*check whether the stack is empty */
    bool isStackEmpty(void) const;
    /*Displays the content of the stack (Academic requirement)*/
    void display(void) const;
};
#endif	/* MYSTACK_H */

